package com.example.myapplication.ui.home;

import android.app.Fragment;

public class HomeSecondFragment extends Fragment {
}
